class StaticpagesController < ApplicationController
  def home
  end

  def about
  end

  def links
  end
end
